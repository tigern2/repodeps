module.exports = function(done, value){
  return {value: value, done: !!done};
};