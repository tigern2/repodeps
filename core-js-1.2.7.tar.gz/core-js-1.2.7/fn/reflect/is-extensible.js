require('../../modules/es6.reflect.is-extensible');
module.exports = require('../../modules/$.core').Reflect.isExtensible;