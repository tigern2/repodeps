require('../../modules/es6.regexp.match');
module.exports = require('../../modules/$.wks')('match');