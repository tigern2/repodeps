require('../../modules/es6.regexp.replace');
module.exports = require('../../modules/$.wks')('replace');