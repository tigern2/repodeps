require('../../modules/core.object.is-object');
module.exports = require('../../modules/$.core').Object.isObject;