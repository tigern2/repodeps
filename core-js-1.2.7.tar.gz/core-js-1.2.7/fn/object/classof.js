require('../../modules/core.object.classof');
module.exports = require('../../modules/$.core').Object.classof;