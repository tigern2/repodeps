require('../../modules/es6.object.is-extensible');
module.exports = require('../../modules/$.core').Object.isExtensible;