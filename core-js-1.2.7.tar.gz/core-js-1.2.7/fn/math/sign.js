require('../../modules/es6.math.sign');
module.exports = require('../../modules/$.core').Math.sign;