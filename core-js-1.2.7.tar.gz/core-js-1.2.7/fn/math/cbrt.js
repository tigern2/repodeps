require('../../modules/es6.math.cbrt');
module.exports = require('../../modules/$.core').Math.cbrt;