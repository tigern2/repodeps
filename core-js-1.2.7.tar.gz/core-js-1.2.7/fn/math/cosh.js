require('../../modules/es6.math.cosh');
module.exports = require('../../modules/$.core').Math.cosh;