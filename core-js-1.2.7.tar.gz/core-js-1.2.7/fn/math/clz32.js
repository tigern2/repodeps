require('../../modules/es6.math.clz32');
module.exports = require('../../modules/$.core').Math.clz32;