require('../modules/core.log');
module.exports = require('../modules/$.core').log;
