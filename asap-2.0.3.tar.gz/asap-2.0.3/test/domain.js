// In Node.js, use the native domain module
// package.json redirects ./domain to ./browser-domain for browsers.
module.exports = require("domain");
