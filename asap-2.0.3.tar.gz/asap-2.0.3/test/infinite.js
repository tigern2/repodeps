

var asap = require("../asap");

function next() {
    asap(next);
}

next();

