"use strict";

window.global_test_results = {
    webkitmutationobserver: typeof WebKitMutationObserver,
    mutationobserver: typeof MutationObserver,
    messagechannel: typeof MessageChannel,
    setimmediate: typeof setImmediate,
    settimeout: typeof setTimeout
};

