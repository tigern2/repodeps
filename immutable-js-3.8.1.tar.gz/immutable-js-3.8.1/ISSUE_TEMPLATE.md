<!--
Have a general question?

First check out the Docs: http://facebook.github.io/immutable-js/docs/
Or ask on Stack Overflow: http://stackoverflow.com/questions/tagged/immutable.js?sort=votes
Stack Overflow gets more attention than this issue list, and is much easier to search.

Found a bug?

Please ensure you're using the latest version, and provide some information below.
-->

### What happened

<!-- Shortly summarize what went wrong. Be sure to include not just what
  happened, but what you expected to happen as well. -->

### How to reproduce

<!-- Provide enough information that someone else could produce the same error.
  Share code or even better, send a Pull Request with a new failing test case. -->
