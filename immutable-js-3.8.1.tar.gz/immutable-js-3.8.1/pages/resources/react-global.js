module.exports = global.React;
