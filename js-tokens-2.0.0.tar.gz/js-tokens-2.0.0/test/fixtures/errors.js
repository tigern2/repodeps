var multiLineString = '\
While I was writing along\
I suddenly forgot to
add a backslash @ the end of a line'

var unterminatedRegex = /3?2:1

# Oops, forgot that this isn’t coffee-script.

/* Let’s try a valid JavaScript comment instead

var string='Pity I forgot to close it, though'
