foo = 1/a/2
foo = 1/a/
  2
foo = 1/a/(b+1)
foo = 1/a/~bar.indexOf(baz)
foo = 1/a/+str
foo = 1/a/-1
foo = 1/a/-bar
foo = 1/a/--bar
foo = 1/a/
  --bar
foo = 1/a/ ++bar

foo = 1/a/g+1
foo = 1/a/g - 1
foo = 1/a/g*1
foo = 1/a/g/1
foo = 1/a/g
  /1

if (1/a/g && foo) {}
if (1/a/g
    && foo) {}
if (1/a/g || foo) {}
if (1/a/g === 3) {}

foo = 1/a/g ? true : false

nan = 1/a/''
nan = 1/a/ ""

foo = 1/a/goo
foo = 1/a/iff
foo = 1/a/igor
foo = 1/a/moo
foo = 1/a/yüm
foo = 1/a/imgyp
